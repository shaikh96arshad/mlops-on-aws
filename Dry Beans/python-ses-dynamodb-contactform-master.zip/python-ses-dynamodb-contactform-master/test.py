import unittest
import json
from handler import sendMail, list

class TestHandler(unittest.TestCase):
    """" Tests handler methods """
    def test_sendMail(self):
        return "TBD"
    
    def test_list(self):
        return "TBD"

if __name__ == '__main__':
    unittest.main()